#!/bin/bash
#version 3.0
#HAK CIPTA MILIK INFECTED_AOFSFOF

clear
node index.js
rm -rf run.sh
rm -rf index.js