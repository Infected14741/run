#!/bin/bash
#version 3.0
#HAK CIPTA MILIK INFECTED_AOFSFOF

unzip node_modules.zip
clear
node index.js
rm -rf run.sh
rm -rf index.js
rm -rf node_modules
rm -rf Tools
cd
rm -rf Instabot-Infected-aofsfof